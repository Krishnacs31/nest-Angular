import { Component } from '@angular/core';

@Component({
  selector: 'app-dept',
  standalone: true,
  imports: [],
  templateUrl: './dept.component.html',
  styleUrl: './dept.component.css'
})
export class DeptComponent {

}
