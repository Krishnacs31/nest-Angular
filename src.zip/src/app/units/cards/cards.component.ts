import { Component } from '@angular/core';

@Component({
  selector: 'app-cards',
  standalone: true,
  imports: [],
  templateUrl: './cards.component.html',
  styleUrl: './cards.component.css'
})
export class CardsComponent {
  dept=[
    {
      id:1,
      Title:"BFS",
      Image:"../../../assets/nestdefence.jpg",
      Description:"dbhjkgfkurgyehjbndfbvd"
    },
    {
      id:2,
      Title:"CFS",
      Image:"../../../assets/nestaero.jpg",
      Description:"dbhjkgfkurgyehjbndfbvd"
    },
    {
      id:3,
      Title:"DFS",
      Image:"../../../assets/nestinsurance.jpg",
      Description:"dbhjkgfkurgyehjbndfbvd"
    },
    {
      id:4,
      Title:"EFS",
      Image:"../../../assets/nestloco.jpg",
      Description:"dbhjkgfkurgyehjbndfbvd"
    }
  ]
}
