import { Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { ContactComponent } from './pages/contact/contact.component';
import { DeptComponent } from './pages/dept/dept.component';
import { AboutComponent } from './pages/about/about.component';

export const routes: Routes = [
    {path:"",component:HomeComponent},
    {path:'contact',component:ContactComponent},
    {path:'dept',component:DeptComponent},
    {path:'about',component:AboutComponent}
];
